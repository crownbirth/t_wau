var app = angular.module("app", []);

app.controller('firstController', function($scope){
   $scope.name="dare";
});